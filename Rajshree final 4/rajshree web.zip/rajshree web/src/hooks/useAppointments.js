import { useState, useEffect, useMemo, useCallback } from 'react';

const APPOINTMENTS_STORAGE_KEY = 'rajshree_hospital_appointments';

// Sample initial seed appointments for testing and demonstration
const SEED_APPOINTMENTS = [
  {
    id: "APT-2026-1001",
    doctorId: 101,
    doctorName: "Dr. Rajeshwar Sharma",
    doctorSpecialty: "Cardiology",
    doctorImage: "",
    room: "Cardio Wing, OPD 301",
    date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0], // 2 days in future
    timeSlot: "10:30 AM",
    duration: "30 mins",
    consultationFee: 1200,
    patientName: "Sampath Kumar",
    patientEmail: "rajshree.patient@health.org",
    patientPhone: "9876543210",
    patientAge: 32,
    patientGender: "Male",
    symptoms: "Periodic chest tightness during light jog, need ECG review",
    status: "Confirmed", // 'Confirmed', 'Completed', 'Cancelled', 'Rescheduled'
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    paymentStatus: "Paid",
    paymentMethod: "Credit Card",
    transactionId: "TXN-982341",
    reminded: true
  },
  {
    id: "APT-2026-1002",
    doctorId: 102,
    doctorName: "Dr. Ananya Sengupta",
    doctorSpecialty: "Psychology & Behavioral Health",
    doctorImage: "",
    room: "Mind Care Suites, Floor 4, Room 408",
    date: new Date(Date.now() + 86400000 * 5).toISOString().split('T')[0], // 5 days in future
    timeSlot: "11:00 AM",
    duration: "45 mins",
    consultationFee: 950,
    patientName: "Sampath Kumar",
    patientEmail: "rajshree.patient@health.org",
    patientPhone: "9876543210",
    patientAge: 32,
    patientGender: "Male",
    symptoms: "Work anxiety and sleep cycle assessment",
    status: "Confirmed",
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    paymentStatus: "Paid",
    paymentMethod: "UPI",
    transactionId: "TXN-761203",
    reminded: false
  },
  {
    id: "APT-2026-1003",
    doctorId: 104,
    doctorName: "Dr. Sneha Kulkarni",
    doctorSpecialty: "Dermatology & Cosmetology",
    doctorImage: "",
    room: "Skin & Laser Center, OPD 202",
    date: new Date(Date.now() - 86400000 * 10).toISOString().split('T')[0], // 10 days in past
    timeSlot: "02:30 PM",
    duration: "25 mins",
    consultationFee: 850,
    patientName: "Sampath Kumar",
    patientEmail: "rajshree.patient@health.org",
    patientPhone: "9876543210",
    patientAge: 32,
    patientGender: "Male",
    symptoms: "Routine seasonal allergy consultation",
    status: "Completed",
    createdAt: new Date(Date.now() - 86400000 * 12).toISOString(),
    paymentStatus: "Paid",
    paymentMethod: "Debit Card",
    transactionId: "TXN-541298",
    reminded: false
  }
];

export const useAppointments = () => {
  const [appointments, setAppointments] = useState(() => {
    try {
      const saved = localStorage.getItem(APPOINTMENTS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : SEED_APPOINTMENTS;
    } catch {
      return SEED_APPOINTMENTS;
    }
  });

  // Current appointment in drafting / selection process
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [appointmentDate, setAppointmentDate] = useState('');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('');
  const [patientDetails, setPatientDetails] = useState({
    name: '',
    email: '',
    phone: '',
    age: '',
    gender: 'Male',
    symptoms: '',
    medicalHistory: ''
  });
  const [bookingStatus, setBookingStatus] = useState('idle'); // 'idle' | 'loading' | 'success' | 'error'
  const [lastBookedAppointment, setLastBookedAppointment] = useState(null);
  const [reminderNotification, setReminderNotification] = useState(null);

  // Sync appointments with localStorage
  useEffect(() => {
    try {
      localStorage.setItem(APPOINTMENTS_STORAGE_KEY, JSON.stringify(appointments));
    } catch (e) {
      console.error('Failed to sync appointments to localStorage:', e);
    }
  }, [appointments]);

  // Appointment reminder check using useEffect
  useEffect(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const upcomingToday = appointments.find(
      (apt) => apt.date === todayStr && apt.status === 'Confirmed'
    );
    if (upcomingToday) {
      setReminderNotification({
        message: `Reminder: You have an appointment with ${upcomingToday.doctorName} today at ${upcomingToday.timeSlot} (${upcomingToday.room})`,
        appointmentId: upcomingToday.id
      });
    }
  }, [appointments]);

  // Memoized appointment statistics & categorization
  const appointmentCount = useMemo(() => appointments.length, [appointments]);

  const upcomingAppointments = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return appointments.filter((apt) => {
      const aptDate = new Date(apt.date + 'T00:00:00');
      return aptDate >= today && (apt.status === 'Confirmed' || apt.status === 'Rescheduled');
    }).sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [appointments]);

  const appointmentHistory = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return appointments.filter((apt) => {
      const aptDate = new Date(apt.date + 'T00:00:00');
      return aptDate < today || apt.status === 'Completed' || apt.status === 'Cancelled';
    }).sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [appointments]);

  // Calculate available time slots for a given doctor on a specific date (filtering out booked ones)
  const getAvailableSlots = useCallback(
    (doctor, date) => {
      if (!doctor || !doctor.availableTimeSlots) return [];
      if (!date) return doctor.availableTimeSlots;

      // Find slots already booked on this date for this doctor that are still active
      const bookedSlots = appointments
        .filter(
          (apt) =>
            apt.doctorId === doctor.id &&
            apt.date === date &&
            (apt.status === 'Confirmed' || apt.status === 'Rescheduled')
        )
        .map((apt) => apt.timeSlot);

      return doctor.availableTimeSlots.filter((slot) => !bookedSlots.includes(slot));
    },
    [appointments]
  );

  // Operations via useCallback
  const selectDoctor = useCallback((doctor) => {
    setSelectedDoctor(doctor);
    setSelectedTimeSlot('');
  }, []);

  const selectTimeSlot = useCallback((slot) => {
    setSelectedTimeSlot(slot);
  }, []);

  const clearAppointment = useCallback(() => {
    setSelectedDoctor(null);
    setAppointmentDate('');
    setSelectedTimeSlot('');
    setPatientDetails({
      name: '',
      email: '',
      phone: '',
      age: '',
      gender: 'Male',
      symptoms: '',
      medicalHistory: ''
    });
    setBookingStatus('idle');
  }, []);

  const bookAppointment = useCallback(
    async (bookingPayload) => {
      setBookingStatus('loading');
      // Simulate asynchronous API processing
      await new Promise((res) => setTimeout(res, 600));

      const newId = `APT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      const newAppointment = {
        id: newId,
        createdAt: new Date().toISOString(),
        status: 'Confirmed',
        duration: '30 mins',
        paymentStatus: 'Paid',
        ...bookingPayload
      };

      setAppointments((prev) => [newAppointment, ...prev]);
      setLastBookedAppointment(newAppointment);
      setBookingStatus('success');
      return newAppointment;
    },
    []
  );

  const rescheduleAppointment = useCallback(
    async (appointmentId, newDate, newSlot) => {
      setAppointments((prev) =>
        prev.map((apt) =>
          apt.id === appointmentId
            ? {
                ...apt,
                date: newDate,
                timeSlot: newSlot,
                status: 'Rescheduled',
                rescheduledAt: new Date().toISOString()
              }
            : apt
        )
      );
      return true;
    },
    []
  );

  const cancelAppointment = useCallback(
    async (appointmentId, reason = 'Cancelled by user') => {
      setAppointments((prev) =>
        prev.map((apt) =>
          apt.id === appointmentId
            ? {
                ...apt,
                status: 'Cancelled',
                cancellationReason: reason,
                cancelledAt: new Date().toISOString()
              }
            : apt
        )
      );
      return true;
    },
    []
  );

  const getAppointmentById = useCallback(
    (id) => {
      return appointments.find((apt) => apt.id === id) || null;
    },
    [appointments]
  );

  return {
    appointments,
    appointmentCount,
    upcomingAppointments,
    appointmentHistory,
    selectedDoctor,
    setSelectedDoctor,
    selectDoctor,
    appointmentDate,
    setAppointmentDate,
    selectedTimeSlot,
    setSelectedTimeSlot,
    selectTimeSlot,
    patientDetails,
    setPatientDetails,
    bookingStatus,
    setBookingStatus,
    lastBookedAppointment,
    setLastBookedAppointment,
    reminderNotification,
    setReminderNotification,
    getAvailableSlots,
    bookAppointment,
    rescheduleAppointment,
    cancelAppointment,
    clearAppointment,
    getAppointmentById
  };
};
