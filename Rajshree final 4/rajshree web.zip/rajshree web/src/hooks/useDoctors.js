import { useState, useEffect, useMemo, useCallback } from 'react';
import { INITIAL_DOCTORS } from '../data/doctorsData';

const DOCTORS_STORAGE_KEY = 'rajshree_hospital_doctors_data';

export const useDoctors = () => {
  // Doctor information state
  const [doctors, setDoctors] = useState(() => {
    try {
      const stored = localStorage.getItem(DOCTORS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : INITIAL_DOCTORS;
    } catch {
      return INITIAL_DOCTORS;
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('All Specialties');
  const [selectedDay, setSelectedDay] = useState('All Days');
  const [maxFee, setMaxFee] = useState(1500);
  const [minRating, setMinRating] = useState(0);
  const [sortBy, setSortBy] = useState('recommended'); // 'recommended', 'rating-high', 'fee-low', 'fee-high', 'experience-high'
  const [isLoading, setIsLoading] = useState(false);

  // Sync doctors with storage
  useEffect(() => {
    try {
      localStorage.setItem(DOCTORS_STORAGE_KEY, JSON.stringify(doctors));
    } catch (e) {
      console.error('Failed to sync doctors to localStorage:', e);
    }
  }, [doctors]);

  // Efficiently calculate filtered doctors using useMemo
  const filteredDoctors = useMemo(() => {
    return doctors
      .filter((doctor) => {
        // Search query match on Name, Specialty, Qualification, Department, Bio
        const query = searchQuery.trim().toLowerCase();
        const matchesSearch =
          !query ||
          doctor.name.toLowerCase().includes(query) ||
          doctor.specialty.toLowerCase().includes(query) ||
          doctor.qualification.toLowerCase().includes(query) ||
          doctor.department.toLowerCase().includes(query) ||
          (doctor.portfolio?.clinicalExpertise &&
            doctor.portfolio.clinicalExpertise.some((exp) => exp.toLowerCase().includes(query)));

        // Specialty filter
        const matchesSpecialty =
          selectedSpecialty === 'All Specialties' || doctor.specialty === selectedSpecialty;

        // Available days filter
        const matchesDay =
          selectedDay === 'All Days' || doctor.availableDays.includes(selectedDay);

        // Fee filter
        const matchesFee = doctor.consultationFee <= maxFee;

        // Rating filter
        const matchesRating = doctor.rating >= minRating;

        return matchesSearch && matchesSpecialty && matchesDay && matchesFee && matchesRating;
      })
      .sort((a, b) => {
        if (sortBy === 'rating-high') return b.rating - a.rating;
        if (sortBy === 'fee-low') return a.consultationFee - b.consultationFee;
        if (sortBy === 'fee-high') return b.consultationFee - a.consultationFee;
        if (sortBy === 'experience-high') return b.experience - a.experience;
        return 0; // recommended preserves default curated order
      });
  }, [doctors, searchQuery, selectedSpecialty, selectedDay, maxFee, minRating, sortBy]);

  // Calculate available doctors count
  const availableDoctorsCount = useMemo(() => filteredDoctors.length, [filteredDoctors]);

  // Helper to retrieve doctor by ID
  const getDoctorById = useCallback(
    (id) => {
      const numericId = parseInt(id, 10);
      return doctors.find((doc) => doc.id === numericId) || null;
    },
    [doctors]
  );

  // Reset filters callback
  const resetFilters = useCallback(() => {
    setSearchQuery('');
    setSelectedSpecialty('All Specialties');
    setSelectedDay('All Days');
    setMaxFee(1500);
    setMinRating(0);
    setSortBy('recommended');
  }, []);

  // Admin capability: add or update doctor
  const addDoctor = useCallback((newDoc) => {
    setDoctors((prev) => [
      ...prev,
      {
        ...newDoc,
        id: Date.now(),
        rating: 5.0,
        reviewsCount: 1
      }
    ]);
  }, []);

  const updateDoctor = useCallback((updatedDoc) => {
    setDoctors((prev) =>
      prev.map((doc) => (doc.id === updatedDoc.id ? { ...doc, ...updatedDoc } : doc))
    );
  }, []);

  return {
    doctors,
    filteredDoctors,
    availableDoctorsCount,
    searchQuery,
    setSearchQuery,
    selectedSpecialty,
    setSelectedSpecialty,
    selectedDay,
    setSelectedDay,
    maxFee,
    setMaxFee,
    minRating,
    setMinRating,
    sortBy,
    setSortBy,
    resetFilters,
    getDoctorById,
    addDoctor,
    updateDoctor,
    isLoading,
    setIsLoading
  };
};
