import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AppointmentProvider } from './context/AppointmentContext';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { ProtectedRoute } from './routes/ProtectedRoute';

// Pages
import { Home } from './pages/Home';
import { DoctorsPage } from './pages/DoctorsPage';
import { DoctorDetailPage } from './pages/DoctorDetailPage';
import { BookAppointmentPage } from './pages/BookAppointmentPage';
import { AppointmentsPage } from './pages/AppointmentsPage';
import { AppointmentDetailPage } from './pages/AppointmentDetailPage';
import { LoginPage } from './pages/LoginPage';
import { PatientDashboardLayout } from './pages/patient/PatientDashboardLayout';
import { PatientOverview } from './pages/patient/PatientOverview';
import { PatientUpcoming } from './pages/patient/PatientUpcoming';
import { PatientHistoryPage } from './pages/patient/PatientHistoryPage';
import { PatientProfilePage } from './pages/patient/PatientProfilePage';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';

function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AppointmentProvider>
          <BrowserRouter>
            <div className="flex flex-col min-h-screen bg-slate-50 text-slate-800">
              {/* Global Navigation Header */}
              <Header />

              {/* Main Routing View */}
              <main className="flex-1">
                <Routes>
                  {/* Public Routes */}
                  <Route path="/" element={<LoginPage />} />
                  <Route path="/home" element={<Home />} />
                  <Route path="/doctors" element={<DoctorsPage />} />
                  <Route path="/doctor/:id" element={<DoctorDetailPage />} />
                  <Route path="/login" element={<LoginPage />} />

                  {/* Protected Appointment Routes */}
                  <Route
                    path="/book-appointment"
                    element={
                      <ProtectedRoute>
                        <BookAppointmentPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/appointments"
                    element={
                      <ProtectedRoute>
                        <AppointmentsPage />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/appointment/:id"
                    element={
                      <ProtectedRoute>
                        <AppointmentDetailPage />
                      </ProtectedRoute>
                    }
                  />

                  {/* Nested Patient Dashboard Routes */}
                  <Route
                    path="/patient"
                    element={
                      <ProtectedRoute allowedRoles={['patient', 'admin']}>
                        <PatientDashboardLayout />
                      </ProtectedRoute>
                    }
                  >
                    <Route index element={<PatientOverview />} />
                    <Route path="appointments" element={<AppointmentsPage />} />
                    <Route path="upcoming" element={<PatientUpcoming />} />
                    <Route path="history" element={<PatientHistoryPage />} />
                    <Route path="profile" element={<PatientProfilePage />} />
                  </Route>

                  {/* Protected Hospital Administration Route */}
                  <Route
                    path="/admin"
                    element={
                      <ProtectedRoute allowedRoles={['admin']}>
                        <AdminDashboardPage />
                      </ProtectedRoute>
                    }
                  />

                  {/* Fallback 404 Route */}
                  <Route
                    path="*"
                    element={
                      <div className="min-h-[50vh] flex flex-col items-center justify-center text-center p-8 space-y-4">
                        <div className="w-16 h-16 rounded-3xl bg-teal-50 text-teal-700 flex items-center justify-center text-2xl font-black">
                          404
                        </div>
                        <h2 className="text-xl font-bold text-slate-800">Page Not Found</h2>
                        <p className="text-xs text-slate-500">
                          The hospital web resource you requested does not exist or has moved.
                        </p>
                        <a
                          href="/"
                          className="px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-bold hover:bg-teal-700 transition"
                        >
                          Return to Home
                        </a>
                      </div>
                    }
                  />
                </Routes>
              </main>

              {/* Global Hospital Footer */}
              <Footer />
            </div>
          </BrowserRouter>
        </AppointmentProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;
