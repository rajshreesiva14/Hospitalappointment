import React, { useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useHospital } from '../context/AppointmentContext';
import { DoctorProfile } from '../components/doctor/DoctorProfile';
import { ChevronLeft, ArrowLeft, Stethoscope, AlertCircle } from 'lucide-react';
import { Button } from '../components/common/Button';

export const DoctorDetailPage = () => {
  // Experiment 3 d: useParams() to retrieve doctor ID from URL
  const { id } = useParams();
  const navigate = useNavigate();
  const { getDoctorById, selectDoctor } = useHospital();

  const doctor = useMemo(() => {
    return getDoctorById(id);
  }, [id, getDoctorById]);

  if (!doctor) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-50 text-amber-600 flex items-center justify-center">
          <AlertCircle className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800">Doctor Profile Not Found</h2>
        <p className="text-sm text-slate-500 max-w-md mx-auto">
          We could not find any registered doctor with ID #{id}. The doctor may have been relocated or the link is invalid.
        </p>
        <div className="pt-2">
          <Button
            variant="primary"
            onClick={() => navigate('/doctors')}
            icon={ArrowLeft}
          >
            Back to Doctors Directory
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-xs font-semibold text-slate-500">
        <Link to="/" className="hover:text-teal-600 transition">
          Home
        </Link>
        <span>/</span>
        <Link to="/doctors" className="hover:text-teal-600 transition">
          Doctors
        </Link>
        <span>/</span>
        <span className="text-teal-700">{doctor.name}</span>
      </nav>

      {/* Back button */}
      <div>
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-teal-700 bg-white border border-slate-200 px-3 py-1.5 rounded-xl hover:bg-slate-50 transition"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to Directory</span>
        </button>
      </div>

      {/* Detailed Profile and Portfolio Component */}
      <DoctorProfile doctor={doctor} onSelectDoctor={selectDoctor} />
    </div>
  );
};
